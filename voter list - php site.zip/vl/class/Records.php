<?php
class Records {	
   
	private $recordsTable = 'voterlist_ayanagar';
	public $id;
	public $vPtNo ;
	public $vSrNo ;
	public $vPolStn;
	public $vRef ;
    public $vName;
	public $vRel ;
    public $vAdd;
	public $vAge;
    public $vSex ;

	private $conn;
	
	public function __construct($db){
        $this->conn = $db;
    }	    
	
	public function listRecords(){
		
		$sqlQuery = "SELECT * FROM ".$this->recordsTable." ";
		if(!empty($_POST["search"]["value"])){
			$sqlQuery .= ' where (vName LIKE "%'.$_POST["search"]["value"].'%" ';
			$sqlQuery .= ' OR vAdd LIKE "%'.$_POST["search"]["value"].'%" ';			
			$sqlQuery .= ' OR vRef LIKE "%'.$_POST["search"]["value"].'%" )';
		}
		
		if(!empty($_POST["order"])){
			$sqlQuery .= 'ORDER BY '.$_POST['order']['0']['column'].' '.$_POST['order']['0']['dir'].' ';
		} else {
			$sqlQuery .= 'ORDER BY id DESC ';
		}
		
		if($_POST["length"] != -1){
			$sqlQuery .= 'LIMIT ' . $_POST['start'] . ', ' . $_POST['length'];
		}
		
		$stmt = $this->conn->prepare($sqlQuery);
		$stmt->execute();
		$result = $stmt->get_result();	
		
		$stmtTotal = $this->conn->prepare("SELECT * FROM ".$this->recordsTable);
		$stmtTotal->execute();
		$allResult = $stmtTotal->get_result();
		$allRecords = $allResult->num_rows;
		
		$displayRecords = $result->num_rows;
		$records = array();		
		while ($record = $result->fetch_assoc()) { 				
			$rows = array();			
			$rows[] = $record['id'];
			$rows[] = $record['vPtNo'];	
			$rows[] = $record['vSrNo'];		
			$rows[] = $record['vPolStn'];	
			$rows[] = $record['vRef'];
			$rows[] = ucfirst($record['vName']);		
			$rows[] = $record['vRel'];
			$rows[] = $record['vAdd'];
			$rows[] = $record['vAge'];
			$rows[] = $record['vSex'];
			$records[] = $rows;
		}
		
		$output = array(
			"draw"	=>	intval($_POST["draw"]),			
			"iTotalRecords"	=> 	$displayRecords,
			"iTotalDisplayRecords"	=>  $allRecords,
			"data"	=> 	$records
		);
		
		echo json_encode($output);
	}
	
	public function getRecord(){
		if($this->id) {
			$sqlQuery = "
				SELECT * FROM ".$this->recordsTable." 
				WHERE id = ?";			
			$stmt = $this->conn->prepare($sqlQuery);
			$stmt->bind_param("i", $this->id);	
			$stmt->execute();
			$result = $stmt->get_result();
			$record = $result->fetch_assoc();
			echo json_encode($record);
		}
	}
}
?>