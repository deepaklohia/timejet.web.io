<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta content="width=device-width, initial-scale=1" name="viewport">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

	<title>MCD Voter List - Aya Nagar Ward</title>
	<script src="js/jquery.dataTables.min.js"></script>
	<script src="js/dataTables.bootstrap.min.js"></script>		
	<link rel="stylesheet" href="css/dataTables.bootstrap.min.css" />
	<script src="js/ajax.js"></script>	

	<!--
   <style>
	body {
	background-image: url('img/logo.png');
	background-repeat: no-repeat;
	background-attachment: fixed; 
	background-size: cover;
	background-size: 12% 25%;
	background-blend-mode: luminosity;
	}
	</style>
	-->

</head>
<body>

<div role="navigation" class="navbar navbar-default navbar-static-top">
	<div class="container">
		
		<div class="navbar-header">
			<button data-target=".navbar-collapse" data-toggle="collapse" class="navbar-toggle" type="button">
			<span class="sr-only">Toggle navigation</span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			</button>
			
			<a class="navbar-brand" href="https://vl.dlohia.com">
				<span><img href="img/logo.png" src="img/logo.png" width="25" class="d-inline-block align-top" alt=""></span>
				<!--
				MCD Voter List - Aya Nagar Ward  &nbsp;&nbsp;<b style="color:#FF9933;"> VOTE for </b><b style="color:#138808;">VEDPAL SHEETAL CHOUDHARY</b>
				-->
			</a>

		</div>

		<div class="navbar-collapse collapse">
			<ul class="nav navbar-nav">
			 
				<li><a href="index.php">Home</a></li>
				<li><a href="https://play.google.com/store/apps/details?id=com.dlohia.voterlist&hl=en_IN&gl=US" target="_blank">Android App</a></li>	
				<li><a href="/dta/voter_list_Ayanagar_ward.xlsx">Excel</a></li>
				<li><a href="/dta/Aya_Nagar_Ward_(combined).pdf" target="_blank">Combined PDF</a></li>
				<li><a href="/dta/Aya_Nagar_Ward_(all_pdf).zip" target="_blank">Single PDF (ZIP)</a></li>
				<li><a href="privacy-policy.php">Privacy Policy</a></li>
				<li><a href="https://dlohia.com/contactus.php">Contact Us</a></li>
				<!--
				<li><a href="/dta/voter_list_Ayanagar_ward.xlsx"><img src="img/xl.png" alt="Download Excel" width="25" height="25"> </a></li>
				<li><a href="/dta/Aya_Nagar_Ward_(combined).pdf" target="_blank"><img src="img/pdf2.png" alt="Download PDF" width="25" height="25"> </a></li>
				-->

			</ul>
		</div><!--/.nav-collapse -->
	</div>
</div>
	
 
<div class="container contact">	
 
	<a href="https://play.google.com/store/apps/details?id=com.dlohia.voterlist&hl=en_IN&gl=US" target="_blank">
		<img src="img/gp.png" alt="Google Play" height="45"> 
	</a>

<!--
	<div class="panel-heading">
		<div class="row">
		
		<b>MCD Voter List - Aya Nagar Ward  </b>
		 
		<img src="img/logo.png" alt="Vote for Vedpal" width="40" height="40">
		<img src="img/logo.png" alt="Vote for Vedpal" width="40" height="40">
		<img src="img/logo.png" alt="Vote for Vedpal" width="40" height="40">

		<a href="/dta/voter_list_Ayanagar_ward.xlsx">
		<img src="img/xl.png" alt="Download Excel" width="50" height="50"> </a>

		<a href="/dta/Aya_Nagar_Ward_(combined).pdf">
		<img src="img/pdf.png" alt="Download PDF" width="50" height="50"> </a>
	 	 
		<a href="#" target="_blank">
		<img src="img/gp.png" alt="Google Play" height="45"> </a>
		 
		</div>
	</div>
	-->
	<table id="recordListing" class="table table-bordered table-striped">
		<thead>
			<tr>
				<th>#.</th>
				<th>PART NO.</th>
				<th>SR. NO.</th>
				<th>POLL. STN.</th>
				<th>REF#</th>
				<th>NAME</th>
				<th>RELATION</th>
				<th>ADDRESS</th>
				<th>AGE</th>
				<th>SEX</th>
			</tr>
		</thead>
	</table>

	<br>
	<div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0);text-align: right;">
		© 2022
		<a class="text-dark" href="https://dlohia.com/">DLA. </a> by Deepak Lohia .
		All Rights Reserved
	</div>

</div>
<br>


<!--
<div class="insert-post-ads1" style="margin-top:20px;">
</div>
-->
</body>
</html>

