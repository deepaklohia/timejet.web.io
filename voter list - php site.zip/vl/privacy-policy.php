<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta content="width=device-width, initial-scale=1" name="viewport">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

	<title>Privacy Policy</title>
	<script src="js/jquery.dataTables.min.js"></script>
	<script src="js/dataTables.bootstrap.min.js"></script>		
	<link rel="stylesheet" href="css/dataTables.bootstrap.min.css" />
	<script src="js/ajax.js"></script>	

	<!--
   <style>
	body {
	background-image: url('img/logo.png');
	background-repeat: no-repeat;
	background-attachment: fixed; 
	background-size: cover;
	background-size: 12% 25%;
	background-blend-mode: luminosity;
	}
	</style>
	-->

</head>
<body>

<div role="navigation" class="navbar navbar-default navbar-static-top">
	<div class="container">
		
		<div class="navbar-header">
			<button data-target=".navbar-collapse" data-toggle="collapse" class="navbar-toggle" type="button">
			<span class="sr-only">Toggle navigation</span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			</button>
			
			<a class="navbar-brand" href="https://vl.dlohia.com">
				<span><img href="img/logo.png" src="img/logo.png" width="25" class="d-inline-block align-top" alt=""></span>
				<!--
				MCD Voter List - Aya Nagar Ward  &nbsp;&nbsp;<b style="color:#FF9933;"> VOTE for </b><b style="color:#138808;">VEDPAL SHEETAL CHOUDHARY</b>
				-->
			</a>

		</div>

		<div class="navbar-collapse collapse">
			<ul class="nav navbar-nav">
			 
				<li><a href="index.php">Home</a></li>
				<li><a href="https://play.google.com/store/apps/details?id=com.dlohia.voterlist&hl=en_IN&gl=US" target="_blank">Android App</a></li>	
				<li><a href="/dta/voter_list_Ayanagar_ward.xlsx">Excel</a></li>
				<li><a href="/dta/Aya_Nagar_Ward_(combined).pdf" target="_blank">Combined PDF</a></li>
				<li><a href="/dta/Aya_Nagar_Ward_(all_pdf).zip" target="_blank">Single PDF (ZIP)</a></li>
				<li><a href="privacy-policy.php">Privacy Policy</a></li>
				<li><a href="https://dlohia.com/contactus.php">Contact Us</a></li>
				<!--
				<li><a href="/dta/voter_list_Ayanagar_ward.xlsx"><img src="img/xl.png" alt="Download Excel" width="25" height="25"> </a></li>
				<li><a href="/dta/Aya_Nagar_Ward_(combined).pdf" target="_blank"><img src="img/pdf2.png" alt="Download PDF" width="25" height="25"> </a></li>
				-->

			</ul>
		</div><!--/.nav-collapse -->
	</div>
</div>
	
 
<div class="container contact">	
	<!--
	<a href="https://play.google.com/store/apps/details?id=com.dlohia.voterlist&hl=en_IN&gl=US" target="_blank">
		<img src="img/gp.png" alt="Google Play" height="45"> 
	</a>
	-->

    <div class="container">
        <div class="row message">
 
            <br>
            <h2><b>Privacy Policy</b></h2>
            <br>
            <p>1.<strong>No personal data is collected</strong>&nbsp;by the developer from the App.</p>
            <br>
            <p>2.<strong>No access to users email is given to the developer</strong> from installation of this App.</p>
            <br>
            <p>3.No access to users personal folders is given to the developer from installation of this App.</p>
            <br>
            <p>4.Any data stored within the App is stored locally on the users account or device.</p>
            <br>
            <p>5.There is no guarantee for support and it could be removed at any time without notice (although this is very unlikely).</p>
            <br>
            <p>6.No guarantee is made for the accuracy, quality or reliability of the service.</p>
			<br>
            <p>6."Voter List" app is NOT affiliated to any government entity. This is the Historical Data collected from Election Commission of India  https://www.eci.gov.in during previous elections.</p>
            <br>
            <p>If you have any questions about this Agreement, please <a href="https://dlohia.com/contactus.php">contact us.</a></p>
		</div> 
	</div> 
 
	<br>
	<div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0);text-align: right;">
		© 2022
		<a class="text-dark" href="https://dlohia.com/">DLA. </a> by Deepak Lohia .
		All Rights Reserved
	</div>

</div>
<br>


<!--
<div class="insert-post-ads1" style="margin-top:20px;">
</div>
-->
</body>
</html>

